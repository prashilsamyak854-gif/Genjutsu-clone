import os, tempfile, gradio as gr
from src.pipeline import generate

def run(reference_video, target_image, prompt, frames, fps):
    if not reference_video or not target_image:
        raise gr.Error("Upload both a reference video and target image.")
    out = generate(reference_video, target_image, prompt or
                   "Preserve the target subject while following the reference video's motion and camera composition.",
                   int(frames), int(fps))
    return out

demo = gr.Interface(
    fn=run,
    inputs=[
        gr.Video(label="Reference video"),
        gr.Image(type="filepath", label="Target image"),
        gr.Textbox(label="Motion / scene instruction"),
        gr.Slider(17, 81, value=49, step=4, label="Frames"),
        gr.Slider(8, 24, value=16, step=1, label="FPS")
    ],
    outputs=gr.Video(label="Generated video"),
    title="Genjutsu-like Video Transfer — V1",
    description="Independent prototype: reference video + target image."
)
demo.launch()
