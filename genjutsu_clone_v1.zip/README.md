# Genjutsu-like Video Transfer — V1

Independent research prototype for reference-video motion transfer.

## Pipeline
1. Reference video preprocessing
2. Optional SAM2 segmentation
3. Motion/camera conditioning hooks
4. Wan image-to-video generation
5. Temporal/post processing

This is not Higgsfield code or weights.

## Hardware
NVIDIA GPU recommended. V1 targets CUDA/PyTorch and short 480p clips.

## Run
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Upload a reference video and target image. The current V1 uses the target image as the generation anchor and extracts reference-video metadata. The motion-conditioning interface is designed for the next trained module.
