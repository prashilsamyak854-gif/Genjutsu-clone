import cv2, os, numpy as np

def inspect_video(path):
    cap=cv2.VideoCapture(path)
    if not cap.isOpened(): raise ValueError("Could not open video")
    fps=cap.get(cv2.CAP_PROP_FPS) or 24
    frames=int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    w=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)); h=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    cap.release()
    return {"fps":fps,"frames":frames,"width":w,"height":h,"duration":frames/fps}

def extract_frames(path, max_frames=81):
    cap=cv2.VideoCapture(path)
    out=[]
    while len(out)<max_frames:
        ok, frame=cap.read()
        if not ok: break
        out.append(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    cap.release()
    return out
