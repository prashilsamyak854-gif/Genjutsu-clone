import os, tempfile, subprocess
from .video_io import inspect_video, extract_frames
from .motion import optical_flow_summary, build_motion_prompt

def generate(reference_video, target_image, prompt, frames=49, fps=16):
    # V1 scaffold: analyze reference and invoke a local image-to-video backend when installed.
    # The trained motion adapter is intentionally a separate module so it can be replaced
    # without changing the UI.
    meta=inspect_video(reference_video)
    sample=extract_frames(reference_video, min(frames, meta["frames"]))
    summary=optical_flow_summary(sample)
    motion_prompt=build_motion_prompt(summary)
    final_prompt=(prompt+" "+motion_prompt+
                  " High temporal consistency, preserve the target subject's identity, "
                  "appearance and proportions. Match the reference composition and camera feel.")
    try:
        from diffusers import DiffusionPipeline
        import torch
        model_id=os.environ.get("WAN_MODEL_ID","Wan-AI/Wan2.1-I2V-14B-480P")
        pipe=DiffusionPipeline.from_pretrained(model_id, torch_dtype=torch.float16)
        pipe.to("cuda")
        from PIL import Image
        image=Image.open(target_image).convert("RGB")
        result=pipe(image=image, prompt=final_prompt, num_frames=frames,
                    guidance_scale=5.0).frames[0]
        out=os.path.join(tempfile.gettempdir(),"genjutsu_v1.mp4")
        try:
            import imageio
            imageio.mimsave(out,result,fps=fps)
        except Exception:
            raise RuntimeError("Video encoding failed; install imageio-ffmpeg.")
        return out
    except Exception as e:
        raise RuntimeError(
            "V1 backend could not run. Install a compatible Wan I2V checkpoint and CUDA "
            "environment. Reference analysis succeeded. Backend error: "+str(e)
        )
