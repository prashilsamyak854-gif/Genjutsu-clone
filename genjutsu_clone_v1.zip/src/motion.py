import cv2, numpy as np

def optical_flow_summary(frames):
    if len(frames)<2: return {"mean_flow":0.0,"vectors":[]}
    prev=cv2.cvtColor(frames[0],cv2.COLOR_RGB2GRAY)
    mags=[]
    for f in frames[1:]:
        gray=cv2.cvtColor(f,cv2.COLOR_RGB2GRAY)
        flow=cv2.calcOpticalFlowFarneback(prev,gray,None,.5,3,15,3,5,1.2,0)
        mag,_=cv2.cartToPolar(flow[...,0],flow[...,1])
        mags.append(float(np.mean(mag)))
        prev=gray
    return {"mean_flow":float(np.mean(mags)),"vectors":mags}

def build_motion_prompt(summary):
    return f"Natural continuous motion; reference motion intensity {summary['mean_flow']:.3f}; preserve stable subject identity and coherent camera movement."
